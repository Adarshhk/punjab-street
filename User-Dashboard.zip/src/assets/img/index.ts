
import alice from '@/assets/img/alice.png';
import angel from '@/assets/img/angel.png';
import zerodha from '@/assets/img/zerodha.png';
import iifl from '@/assets/img/iifl.png';
import mhtrade from '@/assets/img/mhtrade.png';
import profile from '@/assets/img/profile.png';
import profileLarge from '@/assets/img/profileLarge.png';
import graphImg from '@/assets/img/graphImg.png';
import longLogo from '@/assets/logo.svg';
import smallLogo from '@/assets/logo.svg';

export const images: any = {
  alice,
  angel,
  zerodha,
  iifl,
  mhtrade,
  profile,
  profileLarge,
  graphImg,
  longLogo,
  smallLogo

};
