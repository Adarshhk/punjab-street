import colors from "./colors";

export default (app) => {
  app.use(colors);
};
