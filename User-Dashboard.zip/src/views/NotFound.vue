<template>
  <div class="flex flex-col justify-center text-center h-screen bg-cyan-900 text-white">
    <div class="text-5xl">
      <h1>404</h1>
      <h3>Page Not Found</h3>
      <router-link to="/" class="text-blue-500 text-2xl">Move to HomePage</router-link>
    </div>
  </div>
</template>
