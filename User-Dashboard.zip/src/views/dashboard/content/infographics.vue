<template>
  <div class="dashboard  h-[100vh] md:h-[60vh] lg:h-[26vh] lg:bg-[#30437C] sm:h-[100vh] relative text-white p-4 mb-20">
    <!-- Header Section -->
    <div class="flex justify-between bg-[#30437C] w-full p-6  items-center mb-8">
      <div>
        <h1 class="text-2xl font-bold">Hello {{ profile.name }}</h1>
        <p class="text-sm">Welcome back! Let's start your trade with the best strategies by us</p>
      </div>
    </div> 
    <div class="w-full flex justify-center ">
      <div class="grid absolute w-[95%] grid-cols-1 justify-center    lg:grid-cols-3 gap-6">
      <!-- Total Orders Card -->
      <div class="bg-white  dark:bg-secondary dark:text-white text-black p-0 rounded-lg shadow">
       <div class="px-6 pt-2">
        <h2 class="text-xl font-bold">Total Orders</h2>
        <p class="text-3xl font-bold">{{ totalOrders }}</p>
        <p class="text-sm text-gray-500 dark:text-gray-200">Updated 5 min ago</p>
       </div>
        <div class="mt-2">
          <img src="/images/dashboard/graph1.svg" class="w-full rounded-b-md" alt="">
        </div>
      </div>

      <!-- Total Profit Card -->
      <div class="bg-white dark:bg-secondary dark:text-white text-black  p-0 rounded-lg shadow">
     <div class="px-6 pt-2">
      <h2 class="text-xl font-bold">Total Profit</h2>
        <p class="text-3xl font-bold"><TotalProfit /></p>
        <p class="text-sm text-gray-500 dark:text-gray-200">Updated 5 min ago</p>
     </div>
        <div class="mt-2">

        <img src="/images/dashboard/graph1.svg" class="w-full rounded-b-md" alt="">
        </div>
      </div>

      <!-- Brokers Connected Card -->
      <div class="bg-white dark:bg-secondary dark:text-white text-black p-0 rounded-lg shadow">
      <div class="px-6 pt-2">
        <h2 class="text-xl font-bold">Brokers Connected</h2>
        <p class="text-3xl font-bold">{{ brokersTokenMessage }}</p>
        <p class="text-sm text-gray-500 dark:text-gray-200">Updated 5 min ago</p>
      </div>
        <div class="mt-2">
          <img src="/images/dashboard/graph1.svg" alt="" class="w-full rounded-b-md">
        </div>
      </div>

      <!-- Plan Card -->
      <!-- <div class="bg-white text-black p-0 rounded-lg shadow">
        <h2 class="text-xl font-bold">Plan</h2>
        <p class="text-3xl font-bold">{{ profile?.plan_name }}</p>
        <p class="text-sm text-gray-500">Updated 5 min ago</p>
        <div class="mt-2">
          <div class="h-16 bg-blue-200 rounded"></div>
        </div>
      </div> -->
    </div>
    </div>
    <!-- Cards Section -->
   <!-- Closing div for grid section -->
  </div> <!-- Closing div for dashboard -->
</template>

<script setup lang="ts">
import { storeToRefs } from "pinia";
import { computed } from "vue";
import TotalProfit from '@/stores/utils/totalpnl.vue';
import { useProfileStore } from '@/stores/matrix/profile';
import { useBrokersStore } from "@/stores/matrix/broker";
import { useOrdersStore } from "@/stores/matrix/order";
import { useManualOrdersStore } from "@/stores/groups/manualOrders"

// Stores Initialization
const manualOrdersStore = useManualOrdersStore();
const profileStore = useProfileStore();
const brokersStore = useBrokersStore();
const ordersStore = useOrdersStore();

// Profile Data
const { brokers } = storeToRefs(brokersStore);
const { totalRecords } = storeToRefs(ordersStore);

const profile = computed(() => {
  return profileStore.profile;
});

// Expiration Date Logic
let expire_at: any;
expire_at = computed(() => {
  if (profileStore.profile) {
    try {
      return profileStore.profile.expire_at.split("T")[0];
    } catch {
      return "";
    }
  }
});

// Broker Logic: Calculate brokersTokenMessage
interface Broker {
  id: number;
  broker_name: string;
  broker_token_date: string;
  token_status: string;
  message: string;
  updated_at: string;
}

interface BrokerArray extends Array<Broker> {}

const brokersData = computed<BrokerArray>(() => brokers.value);

var brokersTokenMessage = computed(() => {
  const totalBrokers = brokersData.value.length;
  if (totalBrokers > 0) {
    const today = new Date().toISOString().split("T")[0];
    const tokensGeneratedToday = brokersData.value.filter((broker: any) => broker.broker_token_date.split("T")[0] === today && broker.token_status === "success").length;

    let message = tokensGeneratedToday ? `(${tokensGeneratedToday}/${totalBrokers})` : `(0/${totalBrokers})`;

    return message;
  } else {
    return "";
  }
});

// Total Orders Calculation (from ordersStore and manualOrdersStore)
const totalOrders = computed(() => {
  let order = ordersStore.totalOrders;
  let manualOrder = manualOrdersStore.totalManualOrders;
  if (order || manualOrder) {
    return order + manualOrder;
  }
  return 0;
});

</script>

<style scoped>
/* Optional: Custom styles if needed */
</style>
