<template>
  <div
    class="intro-x relative my-2"
    :class="{
      'bg-gray-100': isEven(index),
      'shadow-md dark:shadow-slate-600': fullDetails,
      'shadow-sm dark:shadow-slate-600': !fullDetails
    }"
  >
    <!-- Header for collapsed view -->
    <div class="px-4 py-2" :class="{ 'bg-secondary-dark font-semibold': fullDetails }">
      <div @click="fullDetails = !fullDetails" class="flex justify-between items-center cursor-pointer space-x-4">
        <!-- Strategy name -->
        <div class="flex items-center min-w-[200px]">
          <img v-if="position.broker" class="shadow-none h-4 w-4 mr-2" :src="`${images[position.broker.broker_name]}`" alt="broker" />
          {{ position.strategy.name }}
        </div>

        <!-- Quantity and Buy/Sell type -->
        <div
          class="min-w-[60px] text-center"
         
        >
          {{ position.quantity }}
        </div>

        <!-- Side (Buy/Sell) and Time -->
        <div class=" min-w-[60px] text-center">
          <span :class="pnl < 0 ? 'text-red-400' : pnl > 0 ? 'text-green-400' : ''">{{ position.side }}</span>
        </div>

        <!-- Time -->
        <div class="min-w-[80px] text-center">
         
         <span :class="pnl < 0 ? 'text-red-400' : pnl > 0 ? 'text-green-400' : ''">
           {{ pnl > 0 ? '+' : '' }}{{ pnl? pnl : 0.00 }}
         </span> 
       
       <span>
         <RightArrowIcon class="w-[12px] h-[12px] inline ml-1 transform transition" :class="{ 'rotate-[-90deg]': fullDetails, 'rotate-90': !fullDetails }" />
       </span>
     </div>
      </div>
    </div>

    <!-- Expanded details when toggled -->
    <div v-if="fullDetails" class="p-2 bg-secondary-dark flex">
      <div class="flex w-full h-fit justify-between text-center text-xs xs:text-sm overflow-hidden bg-secondary border-t border-dashed dark:border-slate-600 p-2 pl-4 rounded-lg">
        <!-- Broker Info -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">Broker</div>
          <div v-if="position.broker" class="flex items-center">
            {{ `${position.broker.broker_name} - ${position.broker.broker_userid}` }}
          </div>
          <div v-else>_</div>
        </div>

        <!-- Buy Price -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">Buy Price</div>
          <div v-if="position.side === 'BUY' || position.status !== 'OPEN'">
            <span>{{ position.created_at.split('T')[1].replace('Z', '') }}</span>
            <span> @ ₹{{ position.buy_price }}</span>
          </div>
        </div>

        <!-- Sell Price -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">Sell Price</div>
          <div v-if="position.side === 'SELL' || position.status !== 'OPEN'">
            <span>{{ position.updated_at.split('T')[1].replace('Z', '') }}</span>
            <span> @ ₹{{ position.sell_price }}</span>
          </div>
        </div>

        <!-- Actions -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">ACTIONS</div>
          <button class="delete-btn flex items-center border py-1 px-2 rounded-md dark:border-[#4FBAF0]" @click="deleteSqOff(position)" v-if="position.status === 'OPEN'">
            <DeleteIcon class="w-4 h-4" /> Sq. Off
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
  
  <script setup lang="ts">
  import { images } from '@/assets/img'
  import { ref, computed } from 'vue'

  import  { useTickerStore } from '@/stores/matrix/ticker/ticker'
  
  const tickerStore = useTickerStore()
    
  // define interface to ignore type warning error
  interface Position {
    id: number
    tradingsymbol: string
    strategy_id: number
    broker_id: number
    broker: {
      id: number
      broker_name: string
    }
    user: {
      id: number
      name: string
    }
    strategy: {
      id: number
      name: string
      script: string
      color: string
      image_url: string
    }
    product: string
    instrument_token: number
    quantity: number
    side: string
    last_price: number
    buy_price: number
    sell_price: number
    created_at: string
    updated_at: string
    exchange: string
    status: string
  }
  

  const props = defineProps({
    item: Object
  })

  const fullDetails = ref<boolean>(false)
  
  const position = computed<Position>(() => {
    const position = props.item
    return position as Position
  })
  
  const containsIcon = (data: any) => {
    if (data.strategy.image_url) {
      return true
    }
    return false
  }
  const isEven = (index: number) => index % 2 === 0


  const last_price = computed(() => {
    let token = (position.value.instrument_token).toString()
    const newTick = tickerStore.getLastPrice(token);
    return newTick || position.value.last_price;
  });

  const pnl = computed(() => {
    let result: number = 0

    if (position.value.status == "OPEN") {
        if (position.value.side == "BUY") {
          if (position.value.buy_price != 0 && last_price.value) {

              result = ((last_price.value - position.value.buy_price) * position.value.quantity)
          } else {
              result = 0
          }

        } else if (position.value.side == "SELL" && last_price.value) {
          if (position.value.sell_price != 0) {
              result = ((position.value.sell_price - last_price.value) * position.value.quantity)
          } else {
              result = 0
          }
          } else {
          result = 0
          }
      } else if (position.value.status == "CLOSED") {
          if (position.value.sell_price != 0 && position.value.buy_price != 0) {
              result = ((position.value.sell_price * position.value.quantity) - (position.value.buy_price * position.value.quantity))
          } else {
              result = 0
          }
      }
      return parseFloat(result.toFixed(2));
  })


  
</script>


<style scoped>
.intro-x {
  @apply text-sm !important;
}

</style>