<template>
  <div class="p-4 sm:p-6 bg-white dark:bg-[#0D2B3F] shadow-lg rounded-lg">
    <!-- Header with Toggle Buttons -->
    <div class="flex flex-col sm:flex-row justify-between items-center mb-4">
      <h2 class="text-base sm:text-lg font-semibold text-gray-600 dark:text-white">Select Trade</h2>
      <div class="flex gap-x-2">
        <button 
          :class="['px-3 py-1 rounded-lg font-bold sm:text-lg', { 'bg-[#30437C] text-white': isTabActive === 'Live', 'bg-gray-200 text-gray-600': isTabActive !== 'Live' }]" 
          @click="toggle('Live')">
          Live
        </button>
        <button 
          :class="['px-3 py-1 rounded-lg font-bold sm:text-lg', { 'bg-[#30437C] text-white': isTabActive === 'Paper', 'bg-gray-200 text-gray-600': isTabActive !== 'Paper' }]" 
          @click="toggle('Paper')">
          Paper
        </button>
      </div>
    </div>

    <!-- Total Profit Display -->
    <div class="flex items-center justify-between mb-4">
      <div class="text-4xl font-bold text-[#30437C] dark:text-white">
        {{ `₹${totalPNL.toLocaleString()}` }}
      </div>
    </div>

    <!-- Strategy List Section -->
    <div class="divide-y divide-gray-200">
      <div
        v-for="(strategy, index) in chartData.labels"
        :key="index"
        class="flex justify-between py-2"
      >
        <span class="text-sm text-gray-700 dark:text-white">{{ strategy }}</span>
        <span 
          :class="strategyPNL[index] > 0 ? 'text-green-600' : 'text-red-600'"
        >
          {{ `₹${strategyPNL[index].toFixed(2)} ` }}
          <span v-if="strategyPNL[index] > 0">▲</span>
          <span v-else>▼</span>
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { usePositionsStore } from '@/stores/matrix/position';
import { usePaperPositionsStore } from "@/stores/matrix/paperPositions";
import { storeToRefs } from 'pinia';

// Store setup
const positionsStore = usePositionsStore();
const paperPositionsStore = usePaperPositionsStore();
const { strategiesPositions, isTabActive } = storeToRefs(positionsStore);
const { mainPaperPositions } = storeToRefs(paperPositionsStore);

// Refs and state
const totalPNL = ref(0);

// Toggle function
const toggle = (tab: string) => {
  isTabActive.value = tab;
};

// Chart Data
const chartData = computed(() => {
  const data = isTabActive.value === 'Live'
    ? Object.values(positionsStore.strategiesPositions || {})
    : Object.values(paperPositionsStore.mainPaperPositions || {});

  let chartValue = {
    labels: data.map(strategy => strategy.name),
    datasets: [
      {
        data: data.map(strategy => strategy.positions.length),
        backgroundColor: data.map(strategy => strategy.color),
      },
    ],
  };

  // Update Total Profit
  totalPNL.value = data.reduce((total, strategy) => total + parseFloat(strategy.pnl), 0);

  return chartValue;
});

// Strategy PNL (Profit and Loss)
const strategyPNL = computed(() => {
  const data = isTabActive.value === 'Live'
    ? Object.values(positionsStore.strategiesPositions || {})
    : Object.values(paperPositionsStore.mainPaperPositions || {});

  return data.map(strategy => parseFloat(strategy.pnl));
});
</script>
