<template>
  <div
    class="intro-x relative my-2"
    :class="{
      'bg-gray-100': isEven(index),
      'shadow-md dark:shadow-slate-600': fullDetails,
      'shadow-sm dark:shadow-slate-600': !fullDetails
    }"
  >
    <!-- Header for collapsed view -->
    <div class="px-4 py-2" :class="{ 'bg-secondary-dark font-semibold': fullDetails }">
      <div @click="fullDetails = !fullDetails" class="flex justify-between items-center cursor-pointer space-x-4">
        <!-- Strategy name -->
        <div class="flex items-center  w-[200px]">
          <img v-if="position.broker" class="shadow-none h-4 w-4 mr-2" :src="`${images[position.broker.broker_name]}`" alt="broker" />
          {{ position.strategy.name }}
        </div>

        <!-- Quantity and Buy/Sell type -->
        <div
          class="min-w-[60px] text-center"
        
        >
          {{ position.quantity }}
        </div>

        <!-- Side (Buy/Sell) and Time -->
        <div class=" min-w-[60px] text-center">
          <span :class="pnl < 0 ? 'text-red-400' : pnl > 0 ? 'text-green-400' : ''">{{ position.side }}</span>
        </div>

        <!-- Time -->
        <div class="min-w-[80px] text-center">
         
            <span :class="pnl < 0 ? 'text-red-400' : pnl > 0 ? 'text-green-400' : ''">
              {{ pnl > 0 ? '+' : '' }}{{ pnl? pnl : 0.00 }}
            </span> 
          
          <span>
            <RightArrowIcon class="w-[12px] h-[12px] inline ml-1 transform transition" :class="{ 'rotate-[-90deg]': fullDetails, 'rotate-90': !fullDetails }" />
          </span>
        </div>
      </div>
    </div>

    <!-- Expanded details when toggled -->
    <div v-if="fullDetails" class="p-2 bg-secondary-dark flex">
      <div class="flex w-full h-fit justify-between text-center text-xs xs:text-sm overflow-hidden bg-secondary border-t border-dashed dark:border-slate-600 p-2 pl-4 rounded-lg">
        <!-- Broker Info -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">Broker</div>
          <div v-if="position.broker" class="flex items-center">
            {{ `${position.broker.broker_name} - ${position.broker.broker_userid}` }}
          </div>
          <div v-else>_</div>
        </div>

        <!-- Buy Price -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">Buy Price</div>
          <div v-if="position.side === 'BUY' || position.status !== 'OPEN'">
            <span>{{ position.created_at.split('T')[1].replace('Z', '') }}</span>@

            <span>  ₹{{ position.buy_price }}</span>
          </div>
        </div>

        <!-- Sell Price -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">Sell Price</div>
          <div v-if="position.side === 'SELL' || position.status !== 'OPEN'">
            <span>{{ position.updated_at.split('T')[1].replace('Z', '') }}</span>@

            <span>  ₹{{ position.sell_price }}</span>
          </div>
        </div>

        <!-- Actions -->
        <div class="flex flex-col mb-0">
          <div class="font-semibold">ACTIONS</div>
          <button class="  flex items-center border border-[#3758E6] text-[#3758E6] py-1 px-2 rounded-md dark:border-[#4FBAF0]" @click="deleteSqOff(position)" v-if="position.status === 'OPEN'">
            <DeleteIcon class="w-4 h-4" /> Square. Off
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { images } from '@/assets/img'
import { ref, computed } from 'vue'
import { usePositionsStore } from '@/stores/matrix/position'
import { useTickerStore } from '@/stores/matrix/ticker/ticker'

const positionsStore = usePositionsStore()
const tickerStore = useTickerStore()

interface Position {
  id: number
  tradingsymbol: string
  strategy_id: number
  broker_id: number
  broker: {
    id: number
    broker_name: string
    broker_userid: string
  }
  strategy: {
    id: number
    name: string
  }
  quantity: number
  side: string
  buy_price: number
  sell_price: number
  created_at: string
  updated_at: string
  exchange: string
  status: string
}

const props = defineProps({
  item: Object,
  index: Number // Adding index prop to track position
})

const fullDetails = ref(false)

const position = computed(() => {
  const position = props.item as Position
  return position
})

const pnl = computed(() => {
  let result = 0
  if (position.value.status === 'OPEN') {
    result = (position.value.side === 'BUY' ? position.value.buy_price : position.value.sell_price) - position.value.buy_price
  } else {
    result = position.value.sell_price - position.value.buy_price
  }
  return result.toFixed(2)
})

// Function to check if row is even
const isEven = (index: number) => index % 2 === 0
</script>

<style scoped>
.intro-x {
  @apply text-sm;
}

.bg-gray-100 {
  background-color: #f5f5f5;
}
</style>
