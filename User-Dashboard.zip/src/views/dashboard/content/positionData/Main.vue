<template>
    <div class="w-full mt-2 px-[2px] grid grid-cols-1 xl:grid-cols-2">

      <div class="sub-container  border-r dark:border-[#0D2B3F] border-grey text-nowrap ">
        <div class="pb-2 mt-2">
            <chart />
        </div>
      </div>


      <!-- for mobile device  -->    
      <div class=" pl-2  mt-2">
        <div class="flex justify-between bg-transparent h-[43px]  font-bold text-sm xs:text-base text-tabletext dark:bg-[#0C2B3F] py-2 px-2  ">
          <div class="w-[174px]">STRATEGY NAME</div>
          <div>QTY	</div>
            <div class="">TYPE</div>
            <div>PNL</div>
           
        </div>

        <div class="sub-container2">
          <!-- profile && profile.user_role !== 'Paper' -->
         
          <template v-if="isTabActive === 'Live'">
            <template v-if="(showTableData && positions.length > 0) || (showManualTableData && manualPositions.length > 0)">
              <positionRow v-if="showTableData && mergedPositions.length > 0" v-for="position in mergedPositions" :item="position" />
            </template>
            
            <div v-else-if="!showTableData || !showManualTableData"
              class="flex">
              <LoadingIcon icon="puff" class="w-8 h-8" />
            </div>

            
            <!-- <positionRow v-if="showTableData && positions.length > 0" v-for="position in positions" :item="position" />
            <div v-else-if="!showTableData"
              class="flex my-4">
              <LoadingIcon icon="puff" class="w-8 h-8" />
            </div> -->

            <div v-else class="flex flex-col items-center my-8" >
              <div class="text-center">Data not found!!</div>
            </div>
          </template> 

          <template v-else>
              <paperTradeRow v-if="showPaperPositions && paperPositions.length > 0" v-for="position in paperPositions" :item="position" />

                <div v-else-if="!showPaperPositions"
                  class="flex my-4">
                  <LoadingIcon icon="puff" class="w-8 h-8" />
                </div>
      
                <div v-else class="flex flex-col items-center my-8" >
                  <div class="text-center">Data not found!!</div>
                </div>
          </template> 
        </div>
      </div>
    </div>
  
</template>
  
<script setup lang="ts">
  import { storeToRefs } from 'pinia'
  import { ref, computed } from 'vue'
  import { usePositionsStore } from '@/stores/matrix/position'
  import { useManualPositionsStore } from '@/stores/groups/manualPosition'
  import { useProfileStore } from '@/stores/matrix/profile'
  import positionRow from './positionRow.vue'
  import paperTradeRow  from './paperTradeRow.vue'
  import chart from './chart.vue'

  import { usePaperPositionsStore } from "@/stores/matrix/paperPositions";
  const paperPositionsStore = usePaperPositionsStore();
  const profileStore = useProfileStore();
  const { profile } = storeToRefs(profileStore);
  
  const positionsStore = usePositionsStore()
  const manualPositionsStore = useManualPositionsStore()
  
  const { isTabActive } = storeToRefs(positionsStore)

  // define interface to ignore type warning error
  interface Position {
    id: number
    tradingsymbol: string
    strategy_id: number
    broker_id: number
    broker: {
      id: number
      broker_name: string
    }
    user: {
      id: number
      name: string
    }
    strategy: {
      id: number
      name: string
      script: string
      color: string
      image_url: string
    }
    product: string
    quantity: number
    side: string
    buy_price: number
    sell_price: number
    created_at: string
    updated_at: string
    exchange: string
    status: string
    // pnl: number
  }
  
  
  const positions = computed<Position[]>(() => {
    return positionsStore.positions.map((pos:Position, index: number) => ({
      ...pos,
      serialNo: `position-${index}`
    }));
  })

  const manualPositions = computed<Position[]>(() => {
    return manualPositionsStore.manualPositions.map((pos: Position, index: number) => ({
      ...pos,
      serialNo: `manualPosition-${index}`
    }));
  })

  const mergedPositions = computed<Position[]>(() => {
    const allPositions: Position[] = [...positions.value, ...manualPositions.value];
    if(!allPositions.length) {
      return [];
    }
    // Sort positions by updated_at in descending order
    return allPositions.sort((a, b) => {
      const dateA = new Date(a.updated_at).getTime();
      const dateB = new Date(b.updated_at).getTime();
      return dateB - dateA;
    });

  });


  const showTableData = computed<boolean>(() => {
      const state = positionsStore.state[positionsStore.endpoint];
      return true;
  });
  
  const showManualTableData = computed<boolean>(() => {
      const state = manualPositionsStore.state[manualPositionsStore.endpoint];
      return true;
  })


  const paperPositions = computed<Position[]>(() => {
    const allPositions: Position[] = paperPositionsStore.paperPositions;
    if(!allPositions.length) {
      return [];
    }
    return allPositions.sort((a, b) => {
      const dateA = new Date(a.updated_at).getTime();
      const dateB = new Date(b.updated_at).getTime();
      return dateB - dateA;
    });
  })

  const showPaperPositions = computed<boolean>(() => {
    const state = paperPositionsStore.state[paperPositionsStore.endpoint];
    return true;
  });

</script>
  

<style scoped lang="scss">

.intro-y::-webkit-scrollbar {
  height: 2px;
}

.sub-container {
  @apply xl:h-[calc(100vh-310px)] 2xl:h-[calc(100vh-380px)] w-full overflow-y-scroll;
}
.sub-container2 {
  @apply xl:h-[calc(100vh-310px)] 2xl:h-[calc(100vh-380px)] w-full overflow-y-scroll;
}
</style>

