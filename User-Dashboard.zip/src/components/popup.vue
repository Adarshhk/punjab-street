<template>
  <div
    class="absolute right-20 top-20 bg-white border border-gray-100 rounded h-40 w-56 shadow-sm p-2"
  ></div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
</script>
