<template>
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
    <g id="SVGRepo_iconCarrier">
      <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5"></circle>
      <path
        d="M9 17C9.85038 16.3697 10.8846 16 12 16C13.1154 16 14.1496 16.3697 15 17"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linecap="round"
      ></path>
      <ellipse cx="15" cy="10.5" rx="1" ry="1.5" fill="currentColor"></ellipse>
      <ellipse cx="9" cy="10.5" rx="1" ry="1.5" fill="currentColor"></ellipse>
    </g>
  </svg>
</template>
