
interface AppConfig {
    env: string;
  }
  
  const config: AppConfig = {
    env: 'development',
  };
  
  export default config;
  